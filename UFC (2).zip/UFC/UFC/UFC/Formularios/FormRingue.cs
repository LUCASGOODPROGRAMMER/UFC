﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UFC.Models;
using UFC.Contexto;

namespace UFC.Formularios
{
    public partial class FormRingue : Form
    {
        List<Lutador> lutador = new List<Lutador>();
       
        int cont;
        int cont2;
        int cont3 = 1;
        int id;
        public FormRingue()
        {
            InitializeComponent();

            lutador = Context.ListaLutadores.ToList();

            cbLutador1.DataSource = lutador.ToList();
            cbLutador1.DisplayMember = "Nome";
            cbLutador1.SelectedIndex = -1;
            
            cbLutador2.DataSource = lutador.ToList();
            cbLutador2.DisplayMember = "Nome";
            cbLutador2.SelectedIndex = -1;

            

        }

        private void cbLutador1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelect = cbLutador1.SelectedIndex;
            if (linhaSelect > -1 && cont > 1)
            {
                var dLutador = lutador[linhaSelect];
                txtId.Text = dLutador.Id.ToString();
                txtNome.Text = dLutador.Nome;
                txtAltura.Text = dLutador.altura.ToString();
                txtCategoria.Text = dLutador.Categoria;
            }
            cont++;
        }

        private void cbLutador2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelect = cbLutador2.SelectedIndex;
            if (linhaSelect > -1 && cont > 1)
            {
                var dLutador = lutador[linhaSelect];
                txtId2.Text = dLutador.Id.ToString();
                txtNome2.Text = dLutador.Nome;
                txtAltura2.Text = dLutador.altura.ToString();
                txtCategoria2.Text = dLutador.Categoria;
            }
            cont2++;
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Ringue dLutador = new Ringue();
           
                dLutador.RingueDate = Convert.ToDateTime(txtData.Text);
               dLutador.IdLutador1 = Convert.ToInt32(txtId.Text);
              dLutador.IdLutador2 = Convert.ToInt32(txtId2.Text);
             dLutador.Nome = txtNome.Text;
            dLutador.Nome2 = txtNome2.Text;
             dLutador.altura = Convert.ToDouble(txtAltura.Text);
              dLutador.altura2 = Convert.ToDouble(txtAltura2.Text);
               dLutador.Categoria = txtCategoria.Text;
                dLutador.Categoria2 = txtCategoria2.Text;


            Context.Ringues.Add(dLutador);
          
            id++;
            MessageBox.Show("LUTA TRAVADA", "ANFILTRIÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txtIdBatalha_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
