﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UFC.Models;
using UFC.Contexto;

namespace UFC.Formularios
{
    public partial class FormLutasTravadas : Form
    {
        List<Ringue> ringues = new List<Ringue>();
        List<Lutador> lutadores1 = new List<Lutador>();
        int cont;
        public FormLutasTravadas()
        {
            InitializeComponent();

            ringues = Context.Ringues.ToList();
             Ringue r = new Ringue();
           
              cbLutadores.DataSource = ringues.ToList();
          
            cbLutadores.SelectedIndex = -1;
            
          
        }

        private void cbLutadores_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectLinha = cbLutadores.SelectedIndex;
            if (selectLinha > -1 && cont > 1)
            {
                
                

            }
            cont++;
        }
    }
}
