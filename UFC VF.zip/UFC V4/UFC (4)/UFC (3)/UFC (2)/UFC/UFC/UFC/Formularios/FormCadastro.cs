﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UFC.Formularios;
using UFC.Models;
using UFC.Contexto;

namespace UFC.Formularios
{
    public partial class FormCadastro : Form
    {
        List<Lutador> lutadoresTabela = new List<Lutador>();
        
        
        public int Idz = 1;
        
        
        public FormCadastro()
        {
            InitializeComponent();
            
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            Lutador lutadores = new Lutador();
            lutadores.Nome = txtNome.Text;
            lutadores.altura = Convert.ToDouble(txtAltura.Text);
            lutadores.Categoria = txtCategoria.Text;
            lutadores.Id = Idz;           
            
                lutadoresTabela.Add(lutadores);


                Idz++;
                dtTabela.DataSource = lutadoresTabela.ToList();

                txtNome.Clear(); txtAltura.Clear(); txtCategoria.Clear();
                txtNome.Select();
            
           



        }

        private void btSalvar_Click(object sender, EventArgs e)
        {           
           
            
                Context.ListaLutadores.AddRange(lutadoresTabela); // salvei os dados inserido na tabela2
            lutadoresTabela.Clear();
            dtTabela.DataSource = lutadoresTabela;
                MessageBox.Show("Lutador cadastrado", "ANFILTRIÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
               //else MessageBox.Show("FANTASMA?", "ANFILTRIÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);



        }

        private void btLimparCampo_Click(object sender, EventArgs e)
        {
            txtNome.Clear(); txtAltura.Clear() ; txtCategoria.Clear();
            txtNome.Select();
        }

        private void btDeletTabela_Click(object sender, EventArgs e)
        {
            Idz = Idz - lutadoresTabela.Count();
            lutadoresTabela.Clear();         
            dtTabela.DataSource = lutadoresTabela;
            
        }
    }
}
