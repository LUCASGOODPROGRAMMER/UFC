﻿namespace UFC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCadastrar = new System.Windows.Forms.Button();
            this.btLista = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btBatalha = new System.Windows.Forms.Button();
            this.btCronograma = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btCadastrar
            // 
            this.btCadastrar.AutoSize = true;
            this.btCadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCadastrar.Location = new System.Drawing.Point(171, 40);
            this.btCadastrar.Name = "btCadastrar";
            this.btCadastrar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btCadastrar.Size = new System.Drawing.Size(435, 35);
            this.btCadastrar.TabIndex = 0;
            this.btCadastrar.Text = "CADASTRAR LUTADORES";
            this.btCadastrar.UseVisualStyleBackColor = true;
            this.btCadastrar.Click += new System.EventHandler(this.btCadastrar_Click);
            // 
            // btLista
            // 
            this.btLista.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLista.Location = new System.Drawing.Point(171, 81);
            this.btLista.Name = "btLista";
            this.btLista.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btLista.Size = new System.Drawing.Size(435, 35);
            this.btLista.TabIndex = 1;
            this.btLista.Text = "LISTA DE LUTADORES\r\n\r\n";
            this.btLista.UseVisualStyleBackColor = true;
            this.btLista.Click += new System.EventHandler(this.btLista_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(171, 122);
            this.button1.Name = "button1";
            this.button1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button1.Size = new System.Drawing.Size(435, 35);
            this.button1.TabIndex = 2;
            this.button1.Text = "CONSULTAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btBatalha
            // 
            this.btBatalha.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btBatalha.Location = new System.Drawing.Point(171, 163);
            this.btBatalha.Name = "btBatalha";
            this.btBatalha.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btBatalha.Size = new System.Drawing.Size(435, 35);
            this.btBatalha.TabIndex = 3;
            this.btBatalha.Text = "TRAVAR BATALHA";
            this.btBatalha.UseVisualStyleBackColor = true;
            this.btBatalha.Click += new System.EventHandler(this.btBatalha_Click);
            // 
            // btCronograma
            // 
            this.btCronograma.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCronograma.Location = new System.Drawing.Point(171, 204);
            this.btCronograma.Name = "btCronograma";
            this.btCronograma.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btCronograma.Size = new System.Drawing.Size(435, 35);
            this.btCronograma.TabIndex = 4;
            this.btCronograma.Text = "CRONOGRAMA DE LUTAS";
            this.btCronograma.UseVisualStyleBackColor = true;
            this.btCronograma.Click += new System.EventHandler(this.btCronograma_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 428);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "LUCAS NASCIMENTO HUBNER 2° A INFORMÁTICA";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btCronograma);
            this.Controls.Add(this.btBatalha);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btLista);
            this.Controls.Add(this.btCadastrar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btCadastrar;
        private System.Windows.Forms.Button btLista;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btBatalha;
        private System.Windows.Forms.Button btCronograma;
        private System.Windows.Forms.Label label1;
    }
}

