﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UFC.Models
{
    public class Ringue
    {
        public int IdLutador1 { get; set; }
        public int IdLutador2 { get; set; }   

        public string IdRingue { get; set; }
       
        public DateTime RingueDate { get; set; }       
    }
}
