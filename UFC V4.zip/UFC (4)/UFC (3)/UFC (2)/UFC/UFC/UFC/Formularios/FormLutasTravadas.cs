﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UFC.Models;
using UFC.Contexto;

namespace UFC.Formularios
{
    public partial class FormLutasTravadas : Form
    {
        List<Ringue> ringue = new List<Ringue>();
       

        int cont;
        public FormLutasTravadas()
        {
            InitializeComponent();

            ringue = Context.Ringues.ToList();
            Ringue r = new Ringue();
           
            cbLutadores.DataSource = ringue.ToList();
             cbLutadores.DisplayMember = "RingueDate";          
            cbLutadores.SelectedIndex = -1;
           

        }

        private void cbLutadores_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectLinha = cbLutadores.SelectedIndex;
            if (selectLinha > -1 && cont > 1)
            {
                var idLutador = ringue[selectLinha];
                 txtId.Text = idLutador.IdLutador1.ToString();
                  txtId2.Text = idLutador.IdLutador2.ToString();
                   txtData.Text = idLutador.RingueDate.ToString();
                  var achar = Context.ListaLutadores.Where(a => a.Id == idLutador.IdLutador1).FirstOrDefault();
                 var achar2 = Context.ListaLutadores.Where(a => a.Id == idLutador.IdLutador2).FirstOrDefault();
                  txtId.Text = achar.Id.ToString();
                   txtId2.Text = achar2.Id.ToString();
                    txtNome.Text = achar.Nome;
                     txtNome2.Text = achar2.Nome;
                      txtAltura.Text = achar.altura.ToString();
                       txtAltura2.Text = achar2.altura.ToString();
                        txtCategoria.Text = achar.Categoria;
                         txtCategoria2.Text = achar2.Categoria;
            }
            

            cont++;
        }
    }
}
