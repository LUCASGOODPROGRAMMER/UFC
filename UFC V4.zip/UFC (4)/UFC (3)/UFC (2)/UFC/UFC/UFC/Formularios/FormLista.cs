﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UFC.Contexto;
using UFC.Models;

namespace UFC.Formularios
{
    public partial class FormLista : Form
    {
        List<Lutador> todosLutadores = new List<Lutador>();
        public FormLista()
        {
            InitializeComponent();
            todosLutadores = Context.ListaLutadores.ToList();
            dtTabela.DataSource = todosLutadores.ToList();

        }
    }
}
