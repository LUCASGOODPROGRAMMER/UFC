﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UFC.Formularios;
using UFC.Contexto;

namespace UFC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            FormCadastro form = new FormCadastro();
            form.ShowDialog();
        }

        private void btLista_Click(object sender, EventArgs e)
        {
            if (Context.ListaLutadores.Count == 0) MessageBox.Show("NENHUM LUTADOR FOI REGISTRADO", "ANFILTRIÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                FormLista form = new FormLista();
                form.ShowDialog();
            }
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Context.ListaLutadores.Count == 0) MessageBox.Show("CONSULTA INDISPONÍVEL", "ANFILTRIÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                FormConsulta form = new FormConsulta();
                form.ShowDialog();
            }
           
        }

        private void btBatalha_Click(object sender, EventArgs e)
        {
            if (Context.ListaLutadores.Count < 2) MessageBox.Show("NÃO É POSSIVEL TRAVAR BATALHA!!!", "ANFILTRIÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                FormRingue form = new FormRingue();
                form.ShowDialog();
            }
           
        }

        private void btCronograma_Click(object sender, EventArgs e)
        {
            if (Context.Ringues.Count() == 0) MessageBox.Show("NENHUMA LUTA FOI MARCADADA", "ANFILTRIÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                FormLutasTravadas form = new FormLutasTravadas();
                form.ShowDialog();
            }
           
        }
    }
}
