﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UFC.Models;
namespace UFC.Contexto
{
    public class Context
    {
        public static List<Lutador> ListaLutadores = new List<Lutador>();
    }
}
