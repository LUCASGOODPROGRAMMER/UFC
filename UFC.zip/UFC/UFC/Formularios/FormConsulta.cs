﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UFC.Models;
using UFC.Contexto;

namespace UFC.Formularios
{
    public partial class FormConsulta : Form
    {
        List<Lutador> lutador = new List<Lutador>();
        public FormConsulta()
        {
            InitializeComponent();
            lutador = Context.ListaLutadores.ToList();
            cbLutador.DataSource = lutador.ToList();
            cbLutador.DisplayMember = "NOME";
            cbLutador.SelectedIndex = -1;          
            
            lu
        }
    }
}
