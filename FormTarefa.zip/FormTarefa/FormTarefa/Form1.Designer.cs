﻿namespace FormTarefa
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCadastro = new System.Windows.Forms.Button();
            this.btListagem = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btCadastro
            // 
            this.btCadastro.Location = new System.Drawing.Point(12, 12);
            this.btCadastro.Name = "btCadastro";
            this.btCadastro.Size = new System.Drawing.Size(329, 46);
            this.btCadastro.TabIndex = 0;
            this.btCadastro.Text = "CADASTRAR CLIENTE";
            this.btCadastro.UseVisualStyleBackColor = true;
            this.btCadastro.Click += new System.EventHandler(this.btCadastro_Click);
            // 
            // btListagem
            // 
            this.btListagem.Location = new System.Drawing.Point(12, 73);
            this.btListagem.Name = "btListagem";
            this.btListagem.Size = new System.Drawing.Size(329, 46);
            this.btListagem.TabIndex = 1;
            this.btListagem.Text = "LISTAR CLIENTE";
            this.btListagem.UseVisualStyleBackColor = true;
            this.btListagem.Click += new System.EventHandler(this.btListagem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btListagem);
            this.Controls.Add(this.btCadastro);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btCadastro;
        private System.Windows.Forms.Button btListagem;
    }
}

