﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FormTarefa.Models;
using FormTarefa.Contexto;

namespace FormTarefa.Formularios
{
    public partial class FormCadastrarCliente: Form
    {
        public Cliente cliente = new Cliente();
        int idCliente = 1;
        public FormCadastrarCliente()
        {
            InitializeComponent();
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            while (true) 
            {
                cliente.Id = idCliente;
                cliente.Nome = txtNome.Text;
                cliente.Sexo = txtSexo.Text;
                cliente.DataNascimento = txtDataNascimento.Text;
                cliente.Rg = Convert.ToInt32(txtRg.Text);
                cliente.Cpf = txtCpf.Text;
                cliente.Email = txtEmail.Text;
                cliente.Estado = txtEstado.Text;
                cliente.Cidade = txtCidade.Text;
                cliente.Endereco = txtEndereco.Text;
                cliente.Telefone = txtTelefone.Text;

                if (cliente.Id == null || cliente.Nome == null || cliente.Sexo == null || cliente.DataNascimento == null || cliente.Rg == null || cliente.Cpf == null || cliente.Email == null || cliente.Estado == null || cliente.Cidade == null || cliente.Endereco == null || cliente.Telefone == null)
                {
                    MessageBox.Show("!PREENCHA TODOS OS CAMPOS!", "ADM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else break;
            }
            

            Context.listaClientes.Add(cliente);
            MessageBox.Show("CLIENTE CADASTRADO!!!", "LUCAS NASCIMENTO HUBNER", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtNome.Clear(); txtSexo.Clear(); txtCpf.Clear();
            txtEmail.Clear(); txtEstado.Clear(); txtDataNascimento.Clear();
            txtTelefone.Clear(); txtCidade.Clear(); txtRg.Clear(); txtEndereco.Clear();
            idCliente++;
        }

        private void btLimparCampo_Click(object sender, EventArgs e)
        {
            txtNome.Clear(); txtSexo.Clear(); txtCpf.Clear();
            txtEmail.Clear(); txtEstado.Clear(); txtDataNascimento.Clear();
            txtTelefone.Clear(); txtCidade.Clear(); txtRg.Clear(); txtEndereco.Clear();
        }
    }
}
