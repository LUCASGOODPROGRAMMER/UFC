﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UFC.Formularios;

namespace UFC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            FormCadastro form = new FormCadastro();
            form.ShowDialog();
        }

        private void btLista_Click(object sender, EventArgs e)
        {
            FormLista form = new FormLista();
            form.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormConsulta form = new FormConsulta();
            form.ShowDialog();
        }

        private void btBatalha_Click(object sender, EventArgs e)
        {
            FormRingue form = new FormRingue();
            form.ShowDialog();
        }

        private void btCronograma_Click(object sender, EventArgs e)
        {
            FormLutasTravadas form = new FormLutasTravadas();
            form.ShowDialog();
        }
    }
}
